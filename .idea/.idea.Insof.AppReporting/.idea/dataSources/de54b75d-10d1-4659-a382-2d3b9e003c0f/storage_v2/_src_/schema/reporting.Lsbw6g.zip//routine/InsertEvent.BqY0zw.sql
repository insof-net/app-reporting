create
    definer = reporting@`%` procedure InsertEvent(IN p_Timestamp datetime, IN p_Severity int,
                                                  IN p_SystemName varchar(50), IN p_ApplicationName varchar(50),
                                                  IN p_ApplicationVersion varchar(50), IN p_HostName varchar(128),
                                                  IN p_FilePath varchar(255), IN p_MethodName varchar(255),
                                                  IN p_ClassName varchar(255), IN p_LineNumber int,
                                                  IN p_Message varchar(4000), IN p_ExceptionType varchar(128),
                                                  IN p_ExceptionStackTrace varchar(4000))
begin
    insert into 
        Events (EventTimestamp, Severity, SystemName, ApplicationName, ApplicationVersion, HostName, 
                MethodName, Message, ExceptionType, ExceptionStackTrace, LineNumber, ClassName, FilePath)
    values (p_Timestamp, p_Severity, p_SystemName, p_ApplicationName,
            p_ApplicationVersion, p_HostName, p_MethodName, p_Message,
            p_ExceptionType, p_ExceptionStackTrace, p_LineNumber,
            p_ClassName, p_FilePath);
    
    select last_insert_id();

end;

