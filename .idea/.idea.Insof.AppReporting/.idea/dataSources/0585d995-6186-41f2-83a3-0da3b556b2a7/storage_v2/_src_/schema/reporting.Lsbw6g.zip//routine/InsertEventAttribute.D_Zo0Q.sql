create
    definer = reporting@`%` procedure InsertEventAttribute(IN p_Id bigint, IN p_Name varchar(128), IN p_Value varchar(4000))
begin 
    
    insert into EventAttributes
        (EventId, Name, Value) 
    values (p_Id, p_Name, p_Value);
    
end;

